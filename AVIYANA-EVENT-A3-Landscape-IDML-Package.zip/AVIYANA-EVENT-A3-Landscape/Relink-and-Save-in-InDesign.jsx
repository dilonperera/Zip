#target indesign
(function () {
    var folder = File($.fileName).parent;
    var source = File(folder.fsName + "/AVIYANA-EVENT-A3-Landscape.idml");
    var doc = app.open(source);
    var missing = [];
    for (var i = 0; i < doc.links.length; i++) {
        var link = doc.links[i];
        var file = File(folder.fsName + "/Links/" + link.name);
        if (!file.exists) { missing.push(link.name); continue; }
        link.relink(file); link.update();
    }
    if (missing.length) { alert("Missing links: " + missing.join("\n")); return; }
    doc.save(File(folder.fsName + "/AVIYANA-EVENT-A3-Landscape.indd"));
    alert("Saved INDD with " + doc.pages.length + " pages. Review all pages and run InDesign Preflight before production.");
})();
